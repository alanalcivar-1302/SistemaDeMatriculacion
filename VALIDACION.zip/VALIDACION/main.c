#include "funciones.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <locale.h>
#include <wchar.h>

int main() {
	// Configurar el locale para soportar Unicode
	setlocale(LC_ALL, "");
	
	// Usar wprintf para caracteres Unicode
	wprintf(L"======Bienvenido al sistema de registro veh\u00EDcular======\n");
	
	cargarUsuarios();
	iniciarSesion();
	
	return 0;
}

