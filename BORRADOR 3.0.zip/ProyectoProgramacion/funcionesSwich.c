#include "funciones.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void registroVehiculos(FILE *archivoDatos, int *continuarRegistros){
	
	datosUsuario persona;
	
	archivoDatos = fopen("datosVehiculos.txt","a");
	
	if (archivoDatos == NULL) {
		printf("Error: El archivo no existe.\n");
		registrarLog("ERROR", "main", "No se pudo abrir el archivo datosVehiculos.txt.");
		fclose(archivoDatos);
	}
	else{
		clearInputBuffer();
		
		do {
			
			//ingresar datos del usuario
			printf("Ingrese el nombre del propietario\n");
			validacionEntradaNombre(&persona.nombrePropietario);
			
			limpiarTerminal();
			clearInputBuffer();
			
			printf("Ingrese su numero de cedula \n");
			validacionCedula(&persona.numCedula);
			
			limpiarTerminal();
			
			printf("Ingrese el modelo del vehiculo\n");
			scanf("%s",&persona.modeloAuto);
			
			limpiarTerminal();
			
			clearInputBuffer();
			
			printf("Ingrese la placa (ej: ABC-1234): \n");
			ingresoPlaca(persona.placa);
			
			limpiarTerminal();
			
			printf("Ingresar el color del veh�culo\n");
			scanf("%s",&persona.colorAuto);
			
			limpiarTerminal();
			
			printf("Ingresar a�o del veh�culo\n");
			scanf("%d",&persona.anioAuto);
			
			limpiarTerminal();
			
			//Escribir los datos en el txt 
			fprintf(archivoDatos,"%s,%d,%s,%s,%s,%d\n",persona.nombrePropietario,persona.numCedula, persona.modeloAuto,persona.placa, persona.colorAuto, persona.anioAuto);
			
			printf("Se ha registrado correctamente el veh�culo\n");
			printf("Nombre: %s\n",persona.nombrePropietario);
			printf("Cedula: %d\n",persona.numCedula);
			printf("Modelo: %s\n",persona.modeloAuto);
			printf("Placa: %s\n",persona.placa);
			printf("Color: %s\n",persona.colorAuto);
			printf("A�o vehiculo: %d\n",persona.anioAuto);
			fclose(archivoDatos);
			
			system("pause");
			limpiarTerminal();
			
			printf("Desea registrar otro vehiculo 1. Si, 2. No\n");
			opcionesUsuario(&continuarRegistros,2);
			
		}while(continuarRegistros == 1);
	}
	
}
	

void buscarVehiculo(const char *nombreArchivo, const char *datoBuscado) {
	FILE *archivo = fopen(nombreArchivo, "r");
	char lineasTxt[101];  
	int encontrado = 0;
	
	if (archivo == NULL) {
		printf("No se pudo abrir el archivo.\n");
		return;
	}
	
	while (fgets(lineasTxt, sizeof(lineasTxt), archivo)) {
		
		// Elimina el salto de l�nea final
		lineasTxt[strcspn(lineasTxt, "\n")] = '\0';
		
		// Si la l�nea contiene el dato buscado (placa, c�dula, etc.)
		if (strstr(lineasTxt, datoBuscado) != NULL) {
			printf("L�nea encontrada: %s\n", lineasTxt);
			
			// Separar por comas
			char *campo = strtok(lineasTxt, ",");
			int i = 1;
			
			while (campo != NULL) {
				printf("Campo %d: %s\n", i, campo);
				campo = strtok(NULL, ",");
				i++;
			}
			
			encontrado = 1;
			break; 
		}
	}
	
	if (!encontrado) {
		printf("No se encontr� ning�n registro con '%s'\n", datoBuscado);
	}
	
	fclose(archivo);
	system("pause");
	
}

void valorPago(){
	int nuevoPagomatricula = 1;
	
	while (nuevoPagomatricula) {
		int pagoAtiempo, hizoRevisionVehiculo, diasPago, tipoVehiculo ;
		float multasVehiculo, totalpagoMatricula ;
		
		printf("Seleccione su tipo de veh�culo: \n");
		printf(" 1. Autom�vil \n 2. Motocicleta \n 3. Cami�n \n 4. Bus \n");
		opcionesUsuario(&tipoVehiculo,4);
		
		limpiarTerminal();
		
		printf("�Realiz� la revisi�n t�cnica? (1=S�, 2=No): \n");
		opcionesUsuario(&hizoRevisionVehiculo,2);
		
		limpiarTerminal();
		
		printf("�Pag� la matr�cula a tiempo? (1=S�, 2=No): \n");
		opcionesUsuario(&pagoAtiempo,2);
		
		limpiarTerminal();
		
		printf("�Cu�ntos d�as han pasado desde la notificaci�n?: \n");
		scanf("%d", &diasPago);
		
		limpiarTerminal();
		
		printf("Valor total de multas (sin descuentos): $\n");
		opcionesUsuario(&multasVehiculo,1000);
		
		limpiarTerminal();
		//Total a pagar de la matr�cula
		
		totalpagoMatricula = calcularValormatricula(pagoAtiempo, hizoRevisionVehiculo, diasPago, multasVehiculo, tipoVehiculo) ;
		
		if (totalpagoMatricula >= 0) {
			printf("\n--------------- COMPROBANTE DE MATRICULA ---------------\n");
			printf("Recuerde guardar el comprobante. \n");
			printf("Multas: $%.2f\n", multasVehiculo);
			printf("Total a pagar: $%.2f\n", totalpagoMatricula);
			printf("----------------------------------------------------------\n");
		}
		
		system("pause");
		limpiarTerminal();
		
		// Desea revisar nuevo pago?
		
		printf("\n�Desea procesar otro pago de matr�cula? (1 = S�, 0 = No): \n");
		scanf("%d", &nuevoPagomatricula);
	}
	
	printf("Gracias por preferir nuestro sistema. Regrese mas tarde.\n");
	
}

