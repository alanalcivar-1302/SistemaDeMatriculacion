#include "funciones.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(){

	
	printf("===Bienvenido al sistema de registro veh%ccular.===\n",161);
	cargarUsuarios();
	iniciarSesion();
	
	
	return 0;
}
