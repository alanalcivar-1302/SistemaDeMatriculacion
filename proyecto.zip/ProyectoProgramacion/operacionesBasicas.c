#include "funciones.h"

#include <stdio.h>
#include <stdlib.h>


//Tama�o de car�cteres en arreglos


void limpiarTerminal(){
	system("cls");
}
	
void menu(){
	printf("1. Registrar veh�culo \n");
	printf("2. Buscar veh�culo por placa \n");
	printf("3. Consultar valor a pagar por matricula\n");
	printf("4. Agendar cita de revisi�n\n");
	printf("5. Salir\n");
};
	

void clearInputBuffer(){
	int c;
	while ((c = getchar()) != '\n' && c != EOF);
}

