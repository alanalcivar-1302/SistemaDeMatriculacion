#include "funciones.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void menuIngreso(){
	int opcionUsuario = 0, opcionOperacion = 0;
	FILE *archivoDatos;
	char placaBuscar[TAM_PLACA];
	int opcionIngreso, validacionIngreso;
	while(1) {
		printf("====== Bienvenido al sistema de matriculaci�n vehicular ======\n");
		printf("1. Ingresar\n");
		printf("2. Registrarse\n");
		printf("3. Salir\n");
		printf("Seleccione una opci�n: ");
		scanf("%d", &opcionIngreso);
		if (opcionIngreso == 1) {
			limpiarTerminal();
			validacionIngreso = ingresoUsuario();
			if (validacionIngreso == 1){
				while (opcionUsuario != 5){
					
					menu();
					printf("�Qu� desea realizar?\n");
					opcionesUsuario(&opcionUsuario, 5);
					
					limpiarTerminal();
					
					
					switch (opcionUsuario){
					case 1:
						printf("-----Registro de veh�culos-----\n");
						
						registroVehiculos(&archivoDatos,&opcionOperacion);
						
						break;
					case 2:
						printf("-----Buscar veh�culo-----\n");
						
						clearInputBuffer();
						
						printf("Ingrese la placa (ej: ABC-1234): \n");
						ingresoPlaca(placaBuscar);
						
						limpiarTerminal();
						
						buscarVehiculo("datosVehiculos.txt",placaBuscar);
						
						break;
					case 3:{
						printf("-----Calculo del valor de la matricula-----\n");
						
						valorPago();
						
						break;
					}
					case 4:
							printf("-----Agendar cita de revisi�n-----\n");
							break;
					case 5:
						printf("Gracias por usar nuestro sistema\n");
						break;
					default:
						break;
					}
					limpiarTerminal();
				}
			}
		} else if (opcionIngreso == 2) {
			limpiarTerminal();
			registroUsuario();
		} else if (opcionIngreso == 3) {
			limpiarTerminal();
			printf("Saliendo del sistema...\n");
			exit(0);
		} else {
			printf("Opci�n no v�lida.\n");
		}
	}
}
	
int main(){
	menuIngreso();
	return 0;
}
