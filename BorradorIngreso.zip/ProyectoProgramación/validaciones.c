#include "funciones.h"

#include <stdio.h>
#include <string.h>
#include <time.h>
//================================================================
void registroUsuario() {
	User nuevoUsuario;
	FILE *file = fopen("Usuarios.txt", "a");
	
	
	if (file == NULL) {
		printf("ERROR AL ABRIR EL ARCHIVO.\n");
		return; 
	}
	
	
	printf("Ingrese el nombre de usuario: ");
	scanf("%s", nuevoUsuario.usuario);
	printf("Ingrese la contrase�a: ");
	scanf("%s", nuevoUsuario.contrasena);
	
	
	fprintf(file, "%s,%s\n", nuevoUsuario.usuario, nuevoUsuario.contrasena);
	fclose(file);
	printf("Usuario registrado exitosamente, inicie sesion ahora.\n");
	system("pause");
	limpiarTerminal();
}
int ingresoUsuario() {
	User user; 
	char usuario[USUARIO_LEN];
	char contrasena[CONTRASENA_LEN];
	int found = 0; 
	
	
	printf("Ingrese el nombre de usuario: ");
	scanf("%s", usuario);
	printf("Ingrese la contrase�a: ");
	scanf("%s", contrasena);
	
	
	FILE *file = fopen("Usuarios.txt", "r");
	
	if (file == NULL) {
		printf("Error al abrir el archivo.\n");
		return 0;
	}
	
	
	while (fscanf(file, "%[^,],%s", user.usuario, user.contrasena) != EOF) {
		
		if (strcmp(usuario, user.usuario) == 0 && strcmp(contrasena, user.contrasena) == 0) {
			found = 1; 
			break; 
		}
	}
	fclose(file); 
	
	
	if (found) {
		printf("Ingreso exitoso.\n");
		system("pause");
		limpiarTerminal();
		return 1; 
	} else {
		printf("Usuario o contrase�a incorrectos.\n");
		system("pause");
		limpiarTerminal();
		return 0; 
	}
}
//=====================================================//

void registrarLog(const char *nivel, const char *funcion, const char *mensaje) {
	FILE *log = fopen("log_programa.txt", "a");
	
	if (log == NULL) {
		printf("No se pudo abrir el archivo de log.\n");
		return;
	}
	
	time_t tiempoActual = time(NULL);
	char *tiempoTexto = ctime(&tiempoActual);
	
	// Eliminar salto de l�nea
	for (int i = 0; tiempoTexto[i] != '\0'; i++) {
		if (tiempoTexto[i] == '\n') {
			tiempoTexto[i] = '\0';
			break;
		}
	}
	
	fprintf(log, "[%s] [%s] [%s] %s\n", tiempoTexto, nivel, funcion, mensaje);
	fclose(log);
}

void opcionesUsuario(int *opcionEscoger, int rangoOpciones){
	
	scanf("%d",opcionEscoger);
	while ((*opcionEscoger < 0) || (*opcionEscoger > rangoOpciones)){
		printf("Opcion no valida, ingrese nuevamente (1-%d)\n",rangoOpciones);
		scanf("%d",	opcionEscoger);
	}
};

//Nombre - Caracteres
int validacionCaracteres(char stringValidar[]){
	//int i = 0;
	for (int i = 0; stringValidar[i] != '\0'; i++){
		if ((isalpha(stringValidar[i]) != 0) || (stringValidar[i] = '\0')){
			return 0;
		}
	}
	return 1;
}

void validacionEntradaNombre(char *stringValidar){
	int resultado, intentos = 0;
	do
	{
		if (intentos == 0){
			intentos++;
		}
		else{
			if (intentos == 1){
				printf("Se ingres� informaci�n erronea\n");
			}
		}
		scanf("%s",stringValidar);
		resultado = validacionCaracteres(stringValidar);
	}while(resultado != 0);
	
}
			
//Validacion Cedula

void validacionNumerica(int *valor) {
	
	while (scanf("%d", valor) != 1) {
		clearInputBuffer();
		printf("Entrada inv�lida. Ingrese solo n�meros: \n");
	}
	
}

void validacionCedula(int *cedulaValidar) {
	char cedulaStr[11];
	int intentos = 0;
	
	do {
		if (intentos > 0) {
			printf("C�dula incorrecta, ingrese nuevamente: \n");
		}
		
		validacionNumerica(cedulaValidar); 
		sprintf(cedulaStr, "%d", *cedulaValidar); 
		intentos++;
		
	} while (strlen(cedulaStr) != 10);
}

//Validacion placa
int validarPlaca(char placa[]) {
	if (strlen(placa) != 8)
		return 0;
	
	for (int i = 0; i < 3; i++) {
		if (!isupper(placa[i])) 
			return 0;
	}
	if (placa[3] != '-') 
		return 0;
	
	for (int i = 4; i < 8; i++) {
		if (!isdigit(placa[i])) 
			return 0;
	}
	return 1;
}

void ingresoPlaca(char placa[]) {
	do {
		fgets(placa, TAM_PLACA, stdin);
		placa[strcspn(placa, "\n")] = '\0';
		if (!validarPlaca(placa)) 
			printf("Placa invalida, intente de nuevo.\n");
	} while (!validarPlaca(placa));
}
	
	
	
	
